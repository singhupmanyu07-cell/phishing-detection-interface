import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Shield, Search } from 'lucide-react';

interface URLInputScreenProps {
  onSubmit: (url: string) => void;
}

export function URLInputScreen({ onSubmit }: URLInputScreenProps) {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onSubmit(url.trim());
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="mb-3">Phishing Domain Detector</h1>
          <p className="text-gray-600">
            AI-powered protection against malicious websites. Check any URL instantly to stay safe online.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <label htmlFor="url-input" className="block mb-2 text-gray-700">
              Enter URL to scan
            </label>
            <div className="flex gap-2">
              <Input
                id="url-input"
                type="text"
                placeholder="https://example.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="lg" className="bg-blue-600 hover:bg-blue-700">
                <Search className="w-4 h-4 mr-2" />
                Scan URL
              </Button>
            </div>
          </div>
        </form>

        <div className="mt-8 grid grid-cols-3 gap-4 text-center">
          <div className="bg-white/50 rounded-lg p-4">
            <div className="text-2xl mb-1">⚡</div>
            <div className="text-sm text-gray-600">Instant Results</div>
          </div>
          <div className="bg-white/50 rounded-lg p-4">
            <div className="text-2xl mb-1">🤖</div>
            <div className="text-sm text-gray-600">AI-Powered</div>
          </div>
          <div className="bg-white/50 rounded-lg p-4">
            <div className="text-2xl mb-1">🔒</div>
            <div className="text-sm text-gray-600">Always Secure</div>
          </div>
        </div>
      </div>
    </div>
  );
}
