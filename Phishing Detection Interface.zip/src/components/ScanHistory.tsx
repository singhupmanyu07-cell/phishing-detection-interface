import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Search, Filter, Download, CheckCircle2, AlertTriangle, XCircle, Clock, Shield } from 'lucide-react';
import type { AnalysisResult } from './ResultsScreen';

interface ScanRecord {
  id: string;
  url: string;
  status: 'safe' | 'warning' | 'danger';
  riskScore: number;
  scannedBy: string;
  timestamp: string;
  details: AnalysisResult;
}

export function ScanHistory() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedScan, setSelectedScan] = useState<ScanRecord | null>(null);

  const scanRecords: ScanRecord[] = [
    {
      id: 'SCN-3847',
      url: 'https://paypal-secure-login.tk',
      status: 'danger',
      riskScore: 94,
      scannedBy: 'john.doe@company.com',
      timestamp: '2025-10-10 14:32:15',
      details: {
        url: 'https://paypal-secure-login.tk',
        status: 'danger',
        riskScore: 94,
        factors: [
          { type: 'negative', icon: 'link', text: 'Domain mimics legitimate PayPal site' },
          { type: 'negative', icon: 'clock', text: 'Domain registered 2 days ago' },
          { type: 'negative', icon: 'alert', text: 'Suspicious URL pattern detected' },
          { type: 'negative', icon: 'file', text: 'Page contains credential harvesting form' },
        ]
      }
    },
    {
      id: 'SCN-3846',
      url: 'https://github.com',
      status: 'safe',
      riskScore: 3,
      scannedBy: 'sarah.smith@company.com',
      timestamp: '2025-10-10 14:28:43',
      details: {
        url: 'https://github.com',
        status: 'safe',
        riskScore: 3,
        factors: [
          { type: 'positive', icon: 'shield', text: 'Domain has excellent reputation' },
          { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
          { type: 'positive', icon: 'clock', text: 'Well-established domain' },
        ]
      }
    },
    {
      id: 'SCN-3845',
      url: 'https://free-iphone-winner.com',
      status: 'warning',
      riskScore: 67,
      scannedBy: 'mike.johnson@company.com',
      timestamp: '2025-10-10 14:15:22',
      details: {
        url: 'https://free-iphone-winner.com',
        status: 'warning',
        riskScore: 67,
        factors: [
          { type: 'negative', icon: 'alert', text: 'URL uses attention-grabbing language' },
          { type: 'negative', icon: 'file', text: 'Minimal webpage content' },
          { type: 'positive', icon: 'lock', text: 'SSL certificate present' },
        ]
      }
    },
    {
      id: 'SCN-3844',
      url: 'https://microsoft.com',
      status: 'safe',
      riskScore: 2,
      scannedBy: 'lisa.wong@company.com',
      timestamp: '2025-10-10 13:58:09',
      details: {
        url: 'https://microsoft.com',
        status: 'safe',
        riskScore: 2,
        factors: [
          { type: 'positive', icon: 'shield', text: 'Domain has excellent reputation' },
          { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
          { type: 'positive', icon: 'clock', text: 'Well-established domain' },
        ]
      }
    },
    {
      id: 'SCN-3843',
      url: 'https://amazon-prize-claim.net',
      status: 'danger',
      riskScore: 91,
      scannedBy: 'david.lee@company.com',
      timestamp: '2025-10-10 13:42:31',
      details: {
        url: 'https://amazon-prize-claim.net',
        status: 'danger',
        riskScore: 91,
        factors: [
          { type: 'negative', icon: 'link', text: 'Domain mimics Amazon brand' },
          { type: 'negative', icon: 'clock', text: 'Recently registered domain' },
          { type: 'negative', icon: 'alert', text: 'Phishing pattern detected' },
        ]
      }
    },
    {
      id: 'SCN-3842',
      url: 'https://stackoverflow.com',
      status: 'safe',
      riskScore: 4,
      scannedBy: 'john.doe@company.com',
      timestamp: '2025-10-10 12:15:08',
      details: {
        url: 'https://stackoverflow.com',
        status: 'safe',
        riskScore: 4,
        factors: [
          { type: 'positive', icon: 'shield', text: 'Trusted developer community site' },
          { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
        ]
      }
    },
  ];

  const filteredRecords = scanRecords.filter(record => {
    const matchesSearch = record.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         record.scannedBy.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe': return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      case 'danger': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: string } = {
      safe: 'bg-green-100 text-green-800',
      warning: 'bg-amber-100 text-amber-800',
      danger: 'bg-red-100 text-red-800'
    };
    
    return (
      <Badge className={variants[status]}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="mb-2">Scan History</h1>
          <p className="text-gray-600">
            Complete log of all URL scans performed by your team
          </p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Download className="w-4 h-4 mr-2" />
          Export History
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <div className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search by URL or user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="safe">Safe</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="danger">Danger</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Results Table */}
      <Card>
        <div className="p-6">
          <div className="text-sm text-gray-600 mb-4">
            Showing {filteredRecords.length} of {scanRecords.length} scans
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Scan ID</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Risk Score</TableHead>
                  <TableHead>Scanned By</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.map((record) => (
                  <TableRow key={record.id} className="cursor-pointer hover:bg-gray-50">
                    <TableCell className="text-blue-600">
                      {record.id}
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      {record.url}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(record.status)}
                        {getStatusBadge(record.status)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-1.5 w-16">
                          <div 
                            className={`h-1.5 rounded-full ${
                              record.riskScore >= 80 ? 'bg-red-500' : 
                              record.riskScore >= 50 ? 'bg-amber-500' : 
                              'bg-green-500'
                            }`}
                            style={{ width: `${record.riskScore}%` }}
                          />
                        </div>
                        <span className="text-sm">{record.riskScore}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.scannedBy}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {record.timestamp}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedScan(record)}
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </Card>

      {/* Detail Modal */}
      <Dialog open={!!selectedScan} onOpenChange={() => setSelectedScan(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Scan Details</DialogTitle>
          </DialogHeader>
          {selectedScan && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-600">Scan ID</div>
                  <div className="text-sm">{selectedScan.id}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Timestamp</div>
                  <div className="text-sm">{selectedScan.timestamp}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Scanned By</div>
                  <div className="text-sm">{selectedScan.scannedBy}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Risk Score</div>
                  <div className="text-sm">{selectedScan.riskScore}/100</div>
                </div>
              </div>

              <div>
                <div className="text-sm text-gray-600 mb-2">URL</div>
                <div className="p-3 bg-gray-50 rounded break-all text-sm">
                  {selectedScan.url}
                </div>
              </div>

              <div>
                <div className="text-sm text-gray-600 mb-2">Status</div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(selectedScan.status)}
                  {getStatusBadge(selectedScan.status)}
                </div>
              </div>

              <div>
                <div className="text-sm mb-3">Detection Factors</div>
                <div className="space-y-2">
                  {selectedScan.details.factors.map((factor, idx) => (
                    <div 
                      key={idx}
                      className={`flex items-start gap-2 p-3 rounded-lg ${
                        factor.type === 'positive' ? 'bg-green-50' : 'bg-red-50'
                      }`}
                    >
                      <Shield className={`w-4 h-4 mt-0.5 ${
                        factor.type === 'positive' ? 'text-green-600' : 'text-red-600'
                      }`} />
                      <span className={`text-sm ${
                        factor.type === 'positive' ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {factor.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
