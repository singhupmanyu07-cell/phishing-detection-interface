import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CheckCircle2, AlertTriangle, XCircle, Shield, Loader2, ExternalLink, Settings, History } from 'lucide-react';
import type { AnalysisResult } from './ResultsScreen';

export function BrowserExtensionEnhanced() {
  const [pageStatus, setPageStatus] = useState<'loading' | 'safe' | 'warning' | 'danger'>('safe');
  
  const currentResult: AnalysisResult = {
    url: window.location.href,
    status: pageStatus === 'loading' ? 'safe' : (pageStatus as 'safe' | 'warning' | 'danger'),
    riskScore: pageStatus === 'danger' ? 87 : pageStatus === 'warning' ? 65 : 5,
    factors: pageStatus === 'danger' ? [
      { type: 'negative', icon: 'link', text: 'Domain mimics legitimate site' },
      { type: 'negative', icon: 'clock', text: 'Domain registered recently' },
      { type: 'negative', icon: 'alert', text: 'Suspicious patterns detected' }
    ] : pageStatus === 'warning' ? [
      { type: 'negative', icon: 'alert', text: 'Some suspicious indicators found' },
      { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
    ] : [
      { type: 'positive', icon: 'shield', text: 'Domain has good reputation' },
      { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
      { type: 'positive', icon: 'clock', text: 'Established domain' }
    ]
  };

  const recentScans = [
    { url: 'https://github.com', status: 'safe', score: 5 },
    { url: 'https://stackoverflow.com', status: 'safe', score: 4 },
    { url: 'https://suspicious-login.tk', status: 'danger', score: 92 },
  ];

  return (
    <div className="space-y-8">
      {/* Extension States Visualization */}
      <div>
        <h2 className="mb-4">Browser Extension Icon States</h2>
        <Card>
          <div className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {/* Neutral/Loading State */}
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-lg mb-3 relative">
                  <Shield className="w-8 h-8 text-gray-400" />
                  <Loader2 className="w-16 h-16 text-gray-400 animate-spin absolute" />
                </div>
                <div className="mb-1">Analyzing</div>
                <div className="text-sm text-gray-600">Page is being scanned</div>
              </div>

              {/* Safe State */}
              <div className="text-center cursor-pointer" onClick={() => setPageStatus('safe')}>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-lg mb-3">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <div className="mb-1">Safe</div>
                <div className="text-sm text-gray-600">No threats detected</div>
              </div>

              {/* Warning State */}
              <div className="text-center cursor-pointer" onClick={() => setPageStatus('warning')}>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-amber-100 rounded-lg mb-3">
                  <Shield className="w-8 h-8 text-amber-600" />
                </div>
                <div className="mb-1">Warning</div>
                <div className="text-sm text-gray-600">Suspicious indicators</div>
              </div>

              {/* Danger State */}
              <div className="text-center cursor-pointer" onClick={() => setPageStatus('danger')}>
                <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-lg mb-3">
                  <Shield className="w-8 h-8 text-red-600" />
                </div>
                <div className="mb-1">Danger</div>
                <div className="text-sm text-gray-600">Malicious site detected</div>
              </div>
            </div>
            <div className="mt-4 text-center text-sm text-gray-600">
              Click on any state to preview the extension popup
            </div>
          </div>
        </Card>
      </div>

      {/* Extension Popup Preview */}
      <div>
        <h2 className="mb-4">Extension Popup Interface</h2>
        <div className="flex justify-center">
          <Card className="w-[400px] shadow-2xl">
            <div className="overflow-hidden">
              {/* Header */}
              <div className={`p-4 ${
                pageStatus === 'danger' ? 'bg-red-600' :
                pageStatus === 'warning' ? 'bg-amber-600' :
                pageStatus === 'loading' ? 'bg-gray-600' :
                'bg-green-600'
              } text-white`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    <span>Phishing Detector</span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 h-8 w-8 p-0">
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
                
                {pageStatus === 'loading' ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Analyzing page...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    {pageStatus === 'danger' && <XCircle className="w-5 h-5" />}
                    {pageStatus === 'warning' && <AlertTriangle className="w-5 h-5" />}
                    {pageStatus === 'safe' && <CheckCircle2 className="w-5 h-5" />}
                    <span>
                      {pageStatus === 'danger' ? 'Malicious Site Detected' :
                       pageStatus === 'warning' ? 'Proceed with Caution' :
                       'This Page is Safe'}
                    </span>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4">
                <Tabs defaultValue="current" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-4">
                    <TabsTrigger value="current">Current Page</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                  </TabsList>

                  <TabsContent value="current" className="space-y-4 mt-0">
                    {/* Risk Score */}
                    <div className={`p-4 rounded-lg border-2 ${
                      pageStatus === 'danger' ? 'bg-red-50 border-red-200' :
                      pageStatus === 'warning' ? 'bg-amber-50 border-amber-200' :
                      'bg-green-50 border-green-200'
                    }`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Risk Score</span>
                        <span className="text-2xl">{currentResult.riskScore}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            pageStatus === 'danger' ? 'bg-red-600' :
                            pageStatus === 'warning' ? 'bg-amber-600' :
                            'bg-green-600'
                          }`}
                          style={{ width: `${currentResult.riskScore}%` }}
                        />
                      </div>
                    </div>

                    {/* URL */}
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-xs text-gray-600 mb-1">Current URL:</div>
                      <div className="text-xs break-all">
                        {pageStatus === 'danger' ? 'https://paypal-secure-login.tk' :
                         pageStatus === 'warning' ? 'https://free-prize-winner.com' :
                         'https://github.com'}
                      </div>
                    </div>

                    {/* Detection Factors */}
                    <div>
                      <div className="text-sm mb-3">Detection Summary:</div>
                      <div className="space-y-2">
                        {currentResult.factors.slice(0, 3).map((factor, idx) => (
                          <div 
                            key={idx}
                            className={`flex items-start gap-2 p-2 rounded text-xs ${
                              factor.type === 'positive' ? 'bg-green-50' : 'bg-red-50'
                            }`}
                          >
                            <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                              factor.type === 'positive' ? 'bg-green-500' : 'bg-red-500'
                            }`} />
                            <span className={
                              factor.type === 'positive' ? 'text-green-800' : 'text-red-800'
                            }>
                              {factor.text}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="space-y-2">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700" size="sm">
                        View Full Report
                        <ExternalLink className="w-3 h-3 ml-2" />
                      </Button>
                      {pageStatus === 'danger' && (
                        <Button variant="outline" className="w-full text-red-600 border-red-600 hover:bg-red-50" size="sm">
                          Leave This Page
                        </Button>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="history" className="space-y-2 mt-0">
                    <div className="text-xs text-gray-600 mb-3">Recent scans:</div>
                    {recentScans.map((scan, idx) => (
                      <div key={idx} className="flex items-center gap-2 p-2 rounded hover:bg-gray-50 transition-colors">
                        {scan.status === 'safe' ? (
                          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-xs truncate">{scan.url}</div>
                          <div className="text-xs text-gray-500">Score: {scan.score}/100</div>
                        </div>
                        <Badge className={
                          scan.status === 'safe' 
                            ? 'bg-green-100 text-green-800 text-xs' 
                            : 'bg-red-100 text-red-800 text-xs'
                        }>
                          {scan.status}
                        </Badge>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full mt-3" size="sm">
                      <History className="w-3 h-3 mr-2" />
                      View All History
                    </Button>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Installation Instructions */}
      <Card>
        <div className="p-6">
          <h3 className="mb-4">How to Install</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-3 text-blue-600 text-xl">
                1
              </div>
              <div className="mb-2">Download Extension</div>
              <div className="text-sm text-gray-600">
                Available for Chrome, Firefox, and Edge browsers
              </div>
            </div>
            <div className="text-center p-4">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-3 text-blue-600 text-xl">
                2
              </div>
              <div className="mb-2">Install & Enable</div>
              <div className="text-sm text-gray-600">
                Click "Add to Browser" and grant necessary permissions
              </div>
            </div>
            <div className="text-center p-4">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-3 text-blue-600 text-xl">
                3
              </div>
              <div className="mb-2">Automatic Protection</div>
              <div className="text-sm text-gray-600">
                Every page is automatically scanned as you browse
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
