import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  BookOpen, 
  Shield, 
  Mail, 
  Link as LinkIcon,
  Eye,
  Lock,
  AlertTriangle,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export function EducationalResources() {
  const articles = [
    {
      title: 'Understanding Phishing Attacks',
      description: 'Learn what phishing is, how it works, and why it\'s one of the most common cyber threats.',
      readTime: '5 min read',
      category: 'Basics',
      icon: Shield
    },
    {
      title: 'How to Spot a Phishing Email',
      description: 'Key indicators to identify malicious emails before clicking any links or downloading attachments.',
      readTime: '7 min read',
      category: 'Email Security',
      icon: Mail
    },
    {
      title: 'Checking Links Before You Click',
      description: 'Practical steps to verify URL safety and protect yourself from malicious websites.',
      readTime: '4 min read',
      category: 'Best Practices',
      icon: LinkIcon
    },
    {
      title: 'Common Phishing Techniques',
      description: 'Explore the tactics attackers use, from spear phishing to domain spoofing.',
      readTime: '8 min read',
      category: 'Advanced',
      icon: AlertTriangle
    },
  ];

  const tips = [
    {
      icon: Eye,
      title: 'Always verify the sender',
      description: 'Check the email address carefully. Phishers often use addresses that look similar to legitimate ones.'
    },
    {
      icon: LinkIcon,
      title: 'Hover before you click',
      description: 'Hover over links to preview the URL. If it looks suspicious or doesn\'t match the expected domain, don\'t click.'
    },
    {
      icon: Lock,
      title: 'Look for HTTPS',
      description: 'Legitimate websites use HTTPS encryption. However, remember that phishing sites can also have HTTPS.'
    },
    {
      icon: AlertTriangle,
      title: 'Be wary of urgency',
      description: 'Phishing emails often create a false sense of urgency. Take time to verify before acting.'
    },
    {
      icon: Shield,
      title: 'Use security tools',
      description: 'Leverage tools like this phishing detector to verify suspicious URLs before visiting them.'
    },
    {
      icon: CheckCircle2,
      title: 'Enable 2FA',
      description: 'Two-factor authentication adds an extra layer of protection even if credentials are compromised.'
    },
  ];

  const examples = [
    {
      type: 'danger',
      url: 'http://paypal-secure-login.tk/verify',
      issues: [
        'Uses a suspicious TLD (.tk)',
        'Contains "secure" and "login" keywords',
        'Not the official PayPal domain',
        'Uses HTTP instead of HTTPS'
      ]
    },
    {
      type: 'warning',
      url: 'https://microsfot.com/account/verify',
      issues: [
        'Misspelled domain (microsfot vs microsoft)',
        'Asks for account verification',
        'Could be a typosquatting attempt'
      ]
    },
    {
      type: 'safe',
      url: 'https://www.paypal.com',
      features: [
        'Official domain',
        'HTTPS enabled',
        'No suspicious patterns',
        'Trusted certificate'
      ]
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
          <BookOpen className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="mb-3">Security Education Center</h1>
        <p className="text-gray-600">
          Learn how to protect yourself from phishing attacks and stay safe online
        </p>
      </div>

      {/* Featured Articles */}
      <div>
        <h2 className="mb-4">Featured Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {articles.map((article, idx) => {
            const Icon = article.icon;
            return (
              <Card key={idx} className="hover:shadow-lg transition-shadow cursor-pointer">
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-100 rounded-lg">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {article.category}
                        </Badge>
                        <span className="text-xs text-gray-600">{article.readTime}</span>
                      </div>
                      <h3 className="mb-2 text-lg">{article.title}</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        {article.description}
                      </p>
                      <Button variant="ghost" size="sm" className="text-blue-600">
                        Read Article
                        <ExternalLink className="w-3 h-3 ml-2" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Quick Tips */}
      <div>
        <h2 className="mb-4">Quick Security Tips</h2>
        <Card>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tips.map((tip, idx) => {
                const Icon = tip.icon;
                return (
                  <div key={idx} className="flex gap-3">
                    <div className="p-2 bg-green-100 rounded-lg h-fit">
                      <Icon className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="mb-1">{tip.title}</div>
                      <p className="text-sm text-gray-600">
                        {tip.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
      </div>

      {/* Real Examples */}
      <div>
        <h2 className="mb-4">Real-World Examples</h2>
        <div className="space-y-4">
          {examples.map((example, idx) => (
            <Card key={idx}>
              <div className="p-6">
                <div className="flex items-start gap-4">
                  <Badge className={
                    example.type === 'danger' ? 'bg-red-100 text-red-800' :
                    example.type === 'warning' ? 'bg-amber-100 text-amber-800' :
                    'bg-green-100 text-green-800'
                  }>
                    {example.type.toUpperCase()}
                  </Badge>
                  <div className="flex-1">
                    <div className="p-3 bg-gray-50 rounded font-mono text-sm mb-4 break-all">
                      {example.url}
                    </div>
                    {example.type === 'safe' ? (
                      <div className="space-y-2">
                        <div className="text-sm text-gray-600">Why this is safe:</div>
                        {(example.features || []).map((feature, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="text-sm text-gray-600">Warning signs:</div>
                        {(example.issues || []).map((issue, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm">
                            <AlertTriangle className={`w-4 h-4 mt-0.5 flex-shrink-0 ${
                              example.type === 'danger' ? 'text-red-600' : 'text-amber-600'
                            }`} />
                            <span>{issue}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="p-8 text-center">
          <h2 className="mb-3 text-white">Stay Protected</h2>
          <p className="mb-6 text-blue-100">
            Use our AI-powered tool to check suspicious URLs before clicking them
          </p>
          <Button className="bg-white text-blue-600 hover:bg-gray-100">
            Try the Scanner
          </Button>
        </div>
      </Card>
    </div>
  );
}
