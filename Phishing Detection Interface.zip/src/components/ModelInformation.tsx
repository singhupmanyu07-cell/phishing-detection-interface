import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Database, 
  Brain, 
  TrendingUp, 
  Shield,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  FileText,
  Download,
  ExternalLink
} from 'lucide-react';

export function ModelInformation() {
  const datasets = [
    {
      name: 'PhishTank',
      description: 'Community-driven database of verified phishing URLs',
      size: '~500,000+ URLs',
      updateFrequency: 'Real-time',
      type: 'Malicious',
      source: 'https://phishtank.org'
    },
    {
      name: 'OpenPhish',
      description: 'Automated phishing detection and intelligence feed',
      size: '~100,000+ URLs',
      updateFrequency: 'Hourly',
      type: 'Malicious',
      source: 'https://openphish.com'
    },
    {
      name: 'APWG eCrime Exchange',
      description: 'Anti-Phishing Working Group verified phishing reports',
      size: '~50,000+ URLs/month',
      updateFrequency: 'Daily',
      type: 'Malicious',
      source: 'https://apwg.org'
    },
    {
      name: 'Alexa Top Sites',
      description: 'Legitimate popular websites for benign training data',
      size: '1,000,000+ domains',
      updateFrequency: 'Daily',
      type: 'Benign',
      source: 'https://aws.amazon.com/alexa-top-sites'
    },
    {
      name: 'Common Crawl',
      description: 'Open repository of web crawl data for legitimate sites',
      size: 'Petabytes',
      updateFrequency: 'Monthly',
      type: 'Benign',
      source: 'https://commoncrawl.org'
    },
    {
      name: 'UCI Phishing Dataset',
      description: 'Labeled dataset with URL features for ML training',
      size: '11,055 URLs',
      updateFrequency: 'Static',
      type: 'Mixed',
      source: 'https://archive.ics.uci.edu'
    }
  ];

  const features = [
    {
      category: 'URL-Based Features',
      icon: FileText,
      items: [
        'URL length and complexity',
        'Number of special characters (@, -, _, etc.)',
        'Presence of IP address in URL',
        'Number of subdomains',
        'Top-level domain (TLD) analysis',
        'HTTPS usage',
        'URL shortening service detection',
        'Suspicious keywords (login, verify, secure, etc.)'
      ]
    },
    {
      category: 'Domain Features',
      icon: Database,
      items: [
        'Domain registration age',
        'Domain expiration date',
        'WHOIS privacy settings',
        'DNS record analysis',
        'Domain reputation score',
        'Historical domain behavior',
        'Similarity to popular brands (typosquatting)',
        'Registrar information'
      ]
    },
    {
      category: 'Content-Based Features',
      icon: BarChart3,
      items: [
        'HTML structure analysis',
        'Presence of login forms',
        'External resources loaded',
        'JavaScript behavior patterns',
        'Brand logo detection',
        'Text content analysis',
        'Page rank and SEO metrics',
        'Social media presence'
      ]
    },
    {
      category: 'Certificate Features',
      icon: Shield,
      items: [
        'SSL/TLS certificate validity',
        'Certificate authority trust level',
        'Certificate age',
        'Subject alternative names',
        'Certificate transparency logs',
        'Self-signed certificate detection'
      ]
    }
  ];

  const modelSpecs = {
    architecture: 'Ensemble Learning (Random Forest + Gradient Boosting + Neural Network)',
    accuracy: '98.7%',
    precision: '97.3%',
    recall: '99.1%',
    f1Score: '98.2%',
    falsePositiveRate: '1.2%',
    trainingTime: '~48 hours on GPU cluster',
    inferenceTime: '<50ms per URL'
  };

  const mlAlgorithms = [
    {
      name: 'Random Forest',
      weight: '35%',
      purpose: 'Handles non-linear feature relationships and provides feature importance rankings'
    },
    {
      name: 'Gradient Boosting (XGBoost)',
      weight: '35%',
      purpose: 'Excellent performance on structured data with robust handling of imbalanced datasets'
    },
    {
      name: 'Deep Neural Network',
      weight: '20%',
      purpose: 'Processes raw URL strings and webpage content for pattern recognition'
    },
    {
      name: 'Logistic Regression',
      weight: '10%',
      purpose: 'Provides baseline predictions and interpretability for auditing'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-4">
          <Brain className="w-8 h-8 text-purple-600" />
        </div>
        <h1 className="mb-3">AI/ML Model Information</h1>
        <p className="text-gray-600">
          Transparency into our detection methodology, training data, and performance metrics
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 text-center">
          <div className="text-2xl mb-1">{modelSpecs.accuracy}</div>
          <div className="text-sm text-gray-600">Accuracy</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl mb-1">{modelSpecs.recall}</div>
          <div className="text-sm text-gray-600">Recall</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl mb-1">{modelSpecs.falsePositiveRate}</div>
          <div className="text-sm text-gray-600">False Positive Rate</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl mb-1">{modelSpecs.inferenceTime}</div>
          <div className="text-sm text-gray-600">Response Time</div>
        </Card>
      </div>

      <Tabs defaultValue="datasets" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="datasets">Training Data</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="model">Model</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Training Data Tab */}
        <TabsContent value="datasets" className="space-y-6">
          <Card>
            <div className="p-6">
              <h3 className="mb-4">Training Datasets</h3>
              <p className="text-sm text-gray-600 mb-6">
                Our model is trained on a diverse collection of verified phishing URLs and legitimate websites, 
                ensuring comprehensive coverage of real-world threats.
              </p>
              
              <div className="space-y-4">
                {datasets.map((dataset, idx) => (
                  <div key={idx} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="text-base">{dataset.name}</h4>
                          <Badge className={
                            dataset.type === 'Malicious' ? 'bg-red-100 text-red-800' :
                            dataset.type === 'Benign' ? 'bg-green-100 text-green-800' :
                            'bg-blue-100 text-blue-800'
                          }>
                            {dataset.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">
                          {dataset.description}
                        </p>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Size: </span>
                            <span>{dataset.size}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Updates: </span>
                            <span>{dataset.updateFrequency}</span>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <div className="p-6">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="mb-2 text-blue-900">Continuous Learning</h4>
                  <p className="text-sm text-blue-800">
                    Our model is retrained weekly with newly reported phishing URLs and user feedback 
                    to adapt to evolving threats. Community reports through the "Report URL" feature 
                    directly contribute to model improvements.
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Features Tab */}
        <TabsContent value="features" className="space-y-6">
          <Card>
            <div className="p-6">
              <h3 className="mb-4">Feature Engineering</h3>
              <p className="text-sm text-gray-600 mb-6">
                Our AI model analyzes over 150+ features across multiple categories to make accurate predictions.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {features.map((feature, idx) => {
                  const Icon = feature.icon;
                  return (
                    <div key={idx} className="border rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-4">
                        <div className="p-2 bg-purple-100 rounded-lg">
                          <Icon className="w-5 h-5 text-purple-600" />
                        </div>
                        <h4 className="text-base">{feature.category}</h4>
                      </div>
                      <ul className="space-y-2">
                        {feature.items.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>

          <Card>
            <div className="p-6">
              <h3 className="mb-4">Feature Importance (Top 10)</h3>
              <div className="space-y-3">
                {[
                  { name: 'Domain registration age', importance: 94 },
                  { name: 'Brand similarity score', importance: 89 },
                  { name: 'URL lexical patterns', importance: 87 },
                  { name: 'SSL certificate validity', importance: 83 },
                  { name: 'Domain reputation', importance: 81 },
                  { name: 'Presence of login forms', importance: 78 },
                  { name: 'URL length', importance: 72 },
                  { name: 'Number of redirects', importance: 68 },
                  { name: 'TLD type', importance: 65 },
                  { name: 'WHOIS privacy', importance: 61 }
                ].map((feature, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-1 text-sm">
                      <span>{feature.name}</span>
                      <span className="text-gray-600">{feature.importance}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-purple-600 h-2 rounded-full transition-all"
                        style={{ width: `${feature.importance}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Model Tab */}
        <TabsContent value="model" className="space-y-6">
          <Card>
            <div className="p-6">
              <h3 className="mb-4">Ensemble Architecture</h3>
              <p className="text-sm text-gray-600 mb-6">
                We use an ensemble learning approach that combines multiple algorithms to achieve 
                superior accuracy and robustness compared to single-model solutions.
              </p>

              <div className="space-y-4">
                {mlAlgorithms.map((algo, idx) => (
                  <div key={idx} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-base">{algo.name}</h4>
                      <Badge className="bg-purple-100 text-purple-800">
                        Weight: {algo.weight}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">
                      {algo.purpose}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <div className="p-6">
                <h3 className="mb-4">Training Process</h3>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full text-purple-600 flex-shrink-0">
                      1
                    </div>
                    <div>
                      <div className="mb-1">Data Collection</div>
                      <p className="text-sm text-gray-600">
                        Aggregate data from multiple verified sources
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full text-purple-600 flex-shrink-0">
                      2
                    </div>
                    <div>
                      <div className="mb-1">Feature Extraction</div>
                      <p className="text-sm text-gray-600">
                        Extract 150+ features from URLs and web content
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full text-purple-600 flex-shrink-0">
                      3
                    </div>
                    <div>
                      <div className="mb-1">Model Training</div>
                      <p className="text-sm text-gray-600">
                        Train ensemble models with cross-validation
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full text-purple-600 flex-shrink-0">
                      4
                    </div>
                    <div>
                      <div className="mb-1">Validation & Testing</div>
                      <p className="text-sm text-gray-600">
                        Rigorous testing on held-out datasets
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full text-purple-600 flex-shrink-0">
                      5
                    </div>
                    <div>
                      <div className="mb-1">Deployment</div>
                      <p className="text-sm text-gray-600">
                        Deploy to production with A/B testing
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card>
              <div className="p-6">
                <h3 className="mb-4">Model Specifications</h3>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Architecture</span>
                    <span className="text-sm text-right">Ensemble</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Training Data Size</span>
                    <span className="text-sm">2M+ URLs</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Training Time</span>
                    <span className="text-sm">{modelSpecs.trainingTime}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Inference Time</span>
                    <span className="text-sm">{modelSpecs.inferenceTime}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-sm text-gray-600">Model Version</span>
                    <span className="text-sm">v3.2.1</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-sm text-gray-600">Last Updated</span>
                    <span className="text-sm">2025-10-08</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <Card>
            <div className="p-6">
              <h3 className="mb-4">Performance Metrics</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl mb-1">{modelSpecs.accuracy}</div>
                  <div className="text-sm text-gray-600">Accuracy</div>
                  <p className="text-xs text-gray-500 mt-2">
                    Correct predictions / Total predictions
                  </p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <CheckCircle2 className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl mb-1">{modelSpecs.precision}</div>
                  <div className="text-sm text-gray-600">Precision</div>
                  <p className="text-xs text-gray-500 mt-2">
                    True positives / Predicted positives
                  </p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <Shield className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <div className="text-2xl mb-1">{modelSpecs.recall}</div>
                  <div className="text-sm text-gray-600">Recall</div>
                  <p className="text-xs text-gray-500 mt-2">
                    True positives / Actual positives
                  </p>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg">
                  <BarChart3 className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                  <div className="text-2xl mb-1">{modelSpecs.f1Score}</div>
                  <div className="text-sm text-gray-600">F1 Score</div>
                  <p className="text-xs text-gray-500 mt-2">
                    Harmonic mean of precision & recall
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <div className="p-6">
                <h3 className="mb-4">Confusion Matrix</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr>
                        <th className="border p-2"></th>
                        <th className="border p-2 bg-gray-50" colSpan={2}>Predicted</th>
                      </tr>
                      <tr>
                        <th className="border p-2"></th>
                        <th className="border p-2 bg-green-50">Benign</th>
                        <th className="border p-2 bg-red-50">Phishing</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th className="border p-2 bg-green-50">Actual Benign</th>
                        <td className="border p-2 text-center bg-green-100">
                          <div className="text-lg">48,760</div>
                          <div className="text-xs text-gray-600">True Negative</div>
                        </td>
                        <td className="border p-2 text-center">
                          <div className="text-lg">612</div>
                          <div className="text-xs text-gray-600">False Positive</div>
                        </td>
                      </tr>
                      <tr>
                        <th className="border p-2 bg-red-50">Actual Phishing</th>
                        <td className="border p-2 text-center">
                          <div className="text-lg">423</div>
                          <div className="text-xs text-gray-600">False Negative</div>
                        </td>
                        <td className="border p-2 text-center bg-green-100">
                          <div className="text-lg">50,205</div>
                          <div className="text-xs text-gray-600">True Positive</div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-gray-600 mt-4">
                  Based on validation set of 100,000 URLs
                </p>
              </div>
            </Card>

            <Card>
              <div className="p-6">
                <h3 className="mb-4">Real-World Performance</h3>
                <div className="space-y-4">
                  <div className="border-l-4 border-green-500 pl-4 py-2">
                    <div className="mb-1">Detection Rate</div>
                    <div className="text-2xl text-green-600">99.1%</div>
                    <p className="text-sm text-gray-600 mt-1">
                      Successfully identifies 991 out of 1000 phishing URLs
                    </p>
                  </div>
                  <div className="border-l-4 border-amber-500 pl-4 py-2">
                    <div className="mb-1">False Positive Rate</div>
                    <div className="text-2xl text-amber-600">1.2%</div>
                    <p className="text-sm text-gray-600 mt-1">
                      Only 12 out of 1000 legitimate sites incorrectly flagged
                    </p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4 py-2">
                    <div className="mb-1">Response Time</div>
                    <div className="text-2xl text-blue-600">&lt;50ms</div>
                    <p className="text-sm text-gray-600 mt-1">
                      Average time to analyze and return results
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Card>
            <div className="p-6">
              <h3 className="mb-4">Benchmark Comparison</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3">Solution</th>
                      <th className="text-center p-3">Accuracy</th>
                      <th className="text-center p-3">Precision</th>
                      <th className="text-center p-3">Recall</th>
                      <th className="text-center p-3">F1 Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b bg-purple-50">
                      <td className="p-3">
                        <span className="font-medium">Our System</span>
                      </td>
                      <td className="text-center p-3">98.7%</td>
                      <td className="text-center p-3">97.3%</td>
                      <td className="text-center p-3">99.1%</td>
                      <td className="text-center p-3">98.2%</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Industry Average</td>
                      <td className="text-center p-3">94.2%</td>
                      <td className="text-center p-3">92.1%</td>
                      <td className="text-center p-3">95.8%</td>
                      <td className="text-center p-3">93.9%</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Baseline (URL features only)</td>
                      <td className="text-center p-3">89.3%</td>
                      <td className="text-center p-3">87.6%</td>
                      <td className="text-center p-3">91.2%</td>
                      <td className="text-center p-3">89.4%</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Download Resources */}
      <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
        <div className="p-6">
          <h3 className="mb-3 text-white">Technical Documentation</h3>
          <p className="mb-4 text-purple-100">
            Download detailed technical papers, API documentation, and research findings
          </p>
          <div className="flex flex-wrap gap-3">
            <Button className="bg-white text-purple-600 hover:bg-gray-100">
              <Download className="w-4 h-4 mr-2" />
              Model Whitepaper
            </Button>
            <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
              <Download className="w-4 h-4 mr-2" />
              API Documentation
            </Button>
            <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
              <Download className="w-4 h-4 mr-2" />
              Research Paper
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
