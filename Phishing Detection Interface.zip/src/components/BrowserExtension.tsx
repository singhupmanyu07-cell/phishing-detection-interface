import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle2, AlertTriangle, XCircle, ExternalLink, Shield } from 'lucide-react';
import type { AnalysisResult } from './ResultsScreen';

export function BrowserExtension() {
  const [activeTab, setActiveTab] = useState<'current' | 'recent'>('current');
  
  // Mock current page analysis
  const currentResult: AnalysisResult = {
    url: 'https://secure-login-amazon.com',
    status: 'danger',
    riskScore: 87,
    factors: [
      { type: 'negative', icon: 'link', text: 'Domain mimics legitimate site' },
      { type: 'negative', icon: 'clock', text: 'Domain registered 3 days ago' },
      { type: 'negative', icon: 'alert', text: 'Suspicious URL pattern detected' }
    ]
  };

  const recentScans = [
    { url: 'https://github.com', status: 'safe', score: 5 },
    { url: 'https://paypal-verify.tk', status: 'danger', score: 92 },
    { url: 'https://microsoft.com', status: 'safe', score: 3 },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe': return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      case 'danger': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: any } = {
      safe: 'bg-green-100 text-green-800',
      warning: 'bg-amber-100 text-amber-800',
      danger: 'bg-red-100 text-red-800'
    };
    
    return (
      <Badge className={variants[status]}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  return (
    <div className="w-[380px] bg-white shadow-xl rounded-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-5 h-5" />
          <span className="text-sm">Phishing Detector</span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('current')}
            className={`flex-1 py-1.5 px-3 rounded text-sm transition-colors ${
              activeTab === 'current' 
                ? 'bg-white text-blue-600' 
                : 'bg-blue-500/50 hover:bg-blue-500/70'
            }`}
          >
            Current Page
          </button>
          <button
            onClick={() => setActiveTab('recent')}
            className={`flex-1 py-1.5 px-3 rounded text-sm transition-colors ${
              activeTab === 'recent' 
                ? 'bg-white text-blue-600' 
                : 'bg-blue-500/50 hover:bg-blue-500/70'
            }`}
          >
            Recent Scans
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'current' ? (
          <div className="space-y-4">
            {/* Status Alert */}
            <div className={`p-3 rounded-lg border-2 ${
              currentResult.status === 'danger' 
                ? 'bg-red-50 border-red-200' 
                : currentResult.status === 'warning'
                ? 'bg-amber-50 border-amber-200'
                : 'bg-green-50 border-green-200'
            }`}>
              <div className="flex items-start gap-3">
                {getStatusIcon(currentResult.status)}
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-sm ${
                      currentResult.status === 'danger' ? 'text-red-800' :
                      currentResult.status === 'warning' ? 'text-amber-800' :
                      'text-green-800'
                    }`}>
                      {currentResult.status === 'danger' ? 'Malicious Site Detected' :
                       currentResult.status === 'warning' ? 'Suspicious Site' :
                       'Site is Safe'}
                    </span>
                  </div>
                  <div className={`text-xs ${
                    currentResult.status === 'danger' ? 'text-red-700' :
                    currentResult.status === 'warning' ? 'text-amber-700' :
                    'text-green-700'
                  }`}>
                    Risk Score: {currentResult.riskScore}/100
                  </div>
                </div>
              </div>
            </div>

            {/* URL */}
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-xs text-gray-600 mb-1">Current URL:</div>
              <div className="text-xs break-all">{currentResult.url}</div>
            </div>

            {/* Key Factors */}
            <div>
              <div className="text-xs text-gray-600 mb-2">Key Findings:</div>
              <div className="space-y-2">
                {currentResult.factors.slice(0, 3).map((factor, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs">
                    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                      factor.type === 'positive' ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                    <span className="text-gray-700">{factor.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action */}
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700 text-sm h-9"
              size="sm"
            >
              View Full Report
              <ExternalLink className="w-3 h-3 ml-2" />
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="text-xs text-gray-600 mb-3">Recently scanned URLs:</div>
            {recentScans.map((scan, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2 rounded hover:bg-gray-50 transition-colors">
                {getStatusIcon(scan.status)}
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate">{scan.url}</div>
                  <div className="text-xs text-gray-500">Score: {scan.score}/100</div>
                </div>
                {getStatusBadge(scan.status)}
              </div>
            ))}
            <Button variant="outline" className="w-full text-sm h-9 mt-3" size="sm">
              View All History
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
