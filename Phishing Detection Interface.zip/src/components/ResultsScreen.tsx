import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { RiskGauge } from './RiskGauge';
import { ReportURLModal } from './ReportURLModal';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  ArrowLeft,
  Shield,
  Clock,
  Link as LinkIcon,
  FileText,
  Lock,
  AlertCircle,
  Check,
  X,
  Flag
} from 'lucide-react';

export interface AnalysisResult {
  url: string;
  status: 'safe' | 'warning' | 'danger';
  riskScore: number;
  factors: {
    type: 'positive' | 'negative';
    icon: string;
    text: string;
  }[];
}

interface ResultsScreenProps {
  result: AnalysisResult;
  onBack: () => void;
}

export function ResultsScreen({ result, onBack }: ResultsScreenProps) {
  const [showReportModal, setShowReportModal] = useState(false);

  const getStatusConfig = () => {
    switch (result.status) {
      case 'safe':
        return {
          icon: CheckCircle2,
          title: 'This site appears to be safe',
          description: 'No significant threats detected. You can proceed with confidence.',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200',
          textColor: 'text-green-800',
          iconColor: 'text-green-600'
        };
      case 'warning':
        return {
          icon: AlertTriangle,
          title: 'Proceed with caution',
          description: 'Some suspicious indicators detected. Exercise caution when interacting with this site.',
          bgColor: 'bg-amber-50',
          borderColor: 'border-amber-200',
          textColor: 'text-amber-800',
          iconColor: 'text-amber-600'
        };
      case 'danger':
        return {
          icon: XCircle,
          title: 'Malicious site detected',
          description: 'This site shows strong indicators of phishing. Do not proceed or enter any personal information.',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200',
          textColor: 'text-red-800',
          iconColor: 'text-red-600'
        };
    }
  };

  const config = getStatusConfig();
  const StatusIcon = config.icon;

  const getFactorIcon = (iconType: string) => {
    const icons: { [key: string]: any } = {
      clock: Clock,
      link: LinkIcon,
      file: FileText,
      lock: Lock,
      alert: AlertCircle,
      shield: Shield
    };
    return icons[iconType] || Shield;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 py-8">
      <div className="max-w-3xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={onBack}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Scan Another URL
        </Button>

        <div className="space-y-6">
          {/* Main Result Card */}
          <Card className={`${config.bgColor} ${config.borderColor} border-2`}>
            <div className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <StatusIcon className={`w-8 h-8 ${config.iconColor} flex-shrink-0`} />
                <div className="flex-1">
                  <h2 className={config.textColor}>{config.title}</h2>
                  <p className={`${config.textColor} text-sm opacity-90 mt-1`}>
                    {config.description}
                  </p>
                </div>
              </div>

              <div className="bg-white/60 rounded-lg p-3 break-all">
                <div className="text-sm text-gray-600 mb-1">Scanned URL:</div>
                <div className="text-sm">{result.url}</div>
              </div>
            </div>
          </Card>

          {/* Risk Score */}
          <Card>
            <div className="p-6">
              <h3 className="mb-4 text-center">Risk Assessment</h3>
              <div className="flex justify-center">
                <RiskGauge score={result.riskScore} status={result.status} />
              </div>
              <div className="mt-4 text-center text-sm text-gray-600">
                {result.status === 'safe' && 'Low risk - Safe to proceed'}
                {result.status === 'warning' && 'Medium risk - Caution advised'}
                {result.status === 'danger' && 'High risk - Do not proceed'}
              </div>
            </div>
          </Card>

          {/* Detection Details */}
          <Card>
            <div className="p-6">
              <h3 className="mb-4">Detection Details</h3>
              <p className="text-sm text-gray-600 mb-4">
                AI-analyzed factors that contributed to this assessment:
              </p>
              
              <div className="space-y-3">
                {result.factors.map((factor, index) => {
                  const FactorIcon = getFactorIcon(factor.icon);
                  const isPositive = factor.type === 'positive';
                  
                  return (
                    <div 
                      key={index}
                      className={`flex items-start gap-3 p-3 rounded-lg ${
                        isPositive ? 'bg-green-50' : 'bg-red-50'
                      }`}
                    >
                      <div className={`p-1.5 rounded-full ${
                        isPositive ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {isPositive ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <X className="w-4 h-4 text-red-600" />
                        )}
                      </div>
                      <div className="flex items-center gap-2 flex-1">
                        <FactorIcon className={`w-4 h-4 ${
                          isPositive ? 'text-green-600' : 'text-red-600'
                        }`} />
                        <span className={`text-sm ${
                          isPositive ? 'text-green-800' : 'text-red-800'
                        }`}>
                          {factor.text}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              onClick={onBack}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700"
            >
              Scan Another URL
            </Button>
            <Button 
              onClick={() => setShowReportModal(true)}
              size="lg"
              variant="outline"
              className="border-gray-300"
            >
              <Flag className="w-4 h-4 mr-2" />
              Report Classification
            </Button>
          </div>
        </div>
      </div>

      {/* Report Modal */}
      <ReportURLModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        url={result.url}
        currentStatus={result.status}
      />
    </div>
  );
}
