import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Calendar } from './ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import { 
  Bell, 
  Mail, 
  Download, 
  Calendar as CalendarIcon,
  FileText,
  CheckCircle2,
  Settings
} from 'lucide-react';
import { format } from 'date-fns';

export function AlertsReporting() {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [alertThreshold, setAlertThreshold] = useState('danger');
  const [alertEmail, setAlertEmail] = useState('security@company.com');
  const [reportStartDate, setReportStartDate] = useState<Date>();
  const [reportEndDate, setReportEndDate] = useState<Date>();
  const [reportFormat, setReportFormat] = useState('pdf');

  const handleSaveSettings = () => {
    // Mock save
    alert('Alert settings saved successfully!');
  };

  const handleGenerateReport = () => {
    // Mock report generation
    alert('Report generation started. You will receive it via email shortly.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Alerts & Reporting</h1>
        <p className="text-gray-600">
          Configure automated notifications and generate security reports
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Alert Settings */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <Bell className="w-5 h-5 text-blue-600" />
              <h3>Alert Configuration</h3>
            </div>

            <div className="space-y-6">
              {/* Email Alerts Toggle */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Alerts</Label>
                  <div className="text-sm text-gray-600">
                    Receive email notifications for threats
                  </div>
                </div>
                <Switch
                  checked={emailAlerts}
                  onCheckedChange={setEmailAlerts}
                />
              </div>

              {/* Alert Email */}
              {emailAlerts && (
                <div className="space-y-2">
                  <Label htmlFor="alert-email">Alert Email Address</Label>
                  <div className="flex gap-2">
                    <Mail className="w-4 h-4 text-gray-400 mt-3" />
                    <Input
                      id="alert-email"
                      type="email"
                      value={alertEmail}
                      onChange={(e) => setAlertEmail(e.target.value)}
                      placeholder="security@company.com"
                    />
                  </div>
                </div>
              )}

              {/* Alert Threshold */}
              {emailAlerts && (
                <div className="space-y-2">
                  <Label htmlFor="threshold">Alert Threshold</Label>
                  <Select value={alertThreshold} onValueChange={setAlertThreshold}>
                    <SelectTrigger id="threshold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Scans</SelectItem>
                      <SelectItem value="warning">Warning & Danger</SelectItem>
                      <SelectItem value="danger">Danger Only</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="text-sm text-gray-600">
                    Choose which threat levels trigger alerts
                  </div>
                </div>
              )}

              {/* Additional Settings */}
              <div className="pt-4 border-t space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Daily Summary Report</Label>
                    <div className="text-sm text-gray-600">
                      Receive daily digest at 9:00 AM
                    </div>
                  </div>
                  <Switch />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Weekly Threat Analysis</Label>
                    <div className="text-sm text-gray-600">
                      Comprehensive weekly report
                    </div>
                  </div>
                  <Switch />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Slack Notifications</Label>
                    <div className="text-sm text-gray-600">
                      Post alerts to Slack channel
                    </div>
                  </div>
                  <Switch />
                </div>
              </div>

              <Button 
                onClick={handleSaveSettings}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                <Settings className="w-4 h-4 mr-2" />
                Save Alert Settings
              </Button>
            </div>
          </div>
        </Card>

        {/* Report Generation */}
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <FileText className="w-5 h-5 text-purple-600" />
              <h3>Generate Report</h3>
            </div>

            <div className="space-y-6">
              {/* Date Range */}
              <div className="space-y-2">
                <Label>Report Period</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="justify-start">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {reportStartDate ? format(reportStartDate, 'PP') : 'Start Date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={reportStartDate}
                        onSelect={setReportStartDate}
                      />
                    </PopoverContent>
                  </Popover>

                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="justify-start">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {reportEndDate ? format(reportEndDate, 'PP') : 'End Date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={reportEndDate}
                        onSelect={setReportEndDate}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Quick Presets */}
              <div className="space-y-2">
                <Label>Quick Presets</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const end = new Date();
                      const start = new Date();
                      start.setDate(start.getDate() - 7);
                      setReportStartDate(start);
                      setReportEndDate(end);
                    }}
                  >
                    Last 7 Days
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const end = new Date();
                      const start = new Date();
                      start.setDate(start.getDate() - 30);
                      setReportStartDate(start);
                      setReportEndDate(end);
                    }}
                  >
                    Last 30 Days
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const end = new Date();
                      const start = new Date();
                      start.setDate(start.getDate() - 90);
                      setReportStartDate(start);
                      setReportEndDate(end);
                    }}
                  >
                    Last 90 Days
                  </Button>
                </div>
              </div>

              {/* Report Format */}
              <div className="space-y-2">
                <Label htmlFor="format">Export Format</Label>
                <Select value={reportFormat} onValueChange={setReportFormat}>
                  <SelectTrigger id="format">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">PDF Report</SelectItem>
                    <SelectItem value="csv">CSV Data</SelectItem>
                    <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                    <SelectItem value="json">JSON Data</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Report Contents */}
              <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                <div className="text-sm mb-2">Report will include:</div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Scan statistics and metrics</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Threat breakdown by type</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Top malicious URLs detected</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>User activity summary</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Trend analysis and insights</span>
                </div>
              </div>

              <Button
                onClick={handleGenerateReport}
                disabled={!reportStartDate || !reportEndDate}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                <Download className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Reports */}
      <Card>
        <div className="p-6">
          <h3 className="mb-4">Recent Reports</h3>
          <div className="space-y-2">
            {[
              { name: 'Monthly Security Report - September 2025', date: '2025-10-01', format: 'PDF' },
              { name: 'Weekly Threat Analysis - Week 40', date: '2025-10-07', format: 'PDF' },
              { name: 'Q3 2025 Security Overview', date: '2025-09-30', format: 'Excel' },
            ].map((report, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-purple-600" />
                  <div>
                    <div className="text-sm">{report.name}</div>
                    <div className="text-xs text-gray-600">Generated on {report.date}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{report.format}</Badge>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
