import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Shield, 
  AlertTriangle, 
  Users,
  TrendingUp,
  Search,
  Clock,
  XCircle,
  ChevronRight,
  Activity
} from 'lucide-react';

interface DashboardProps {
  onNavigate: (page: string) => void;
  onScanURL: (url: string) => void;
}

export function OrganizationalDashboard({ onNavigate, onScanURL }: DashboardProps) {
  const [quickScanURL, setQuickScanURL] = useState('');

  const stats = [
    { 
      label: 'Total Scans (30d)', 
      value: '3,847', 
      change: '+18%', 
      trend: 'up',
      icon: Shield, 
      color: 'blue' 
    },
    { 
      label: 'Threats Blocked', 
      value: '127', 
      change: '+12%', 
      trend: 'up',
      icon: AlertTriangle, 
      color: 'red' 
    },
    { 
      label: 'Protected Users', 
      value: '234', 
      change: '+5%', 
      trend: 'up',
      icon: Users, 
      color: 'green' 
    },
    { 
      label: 'Detection Rate', 
      value: '98.7%', 
      change: '+1.2%', 
      trend: 'up',
      icon: TrendingUp, 
      color: 'purple' 
    },
  ];

  const threatTypes = [
    { type: 'Credential Phishing', count: 48, percentage: 38 },
    { type: 'Brand Impersonation', count: 35, percentage: 28 },
    { type: 'Domain Spoofing', count: 27, percentage: 21 },
    { type: 'Malware Distribution', count: 17, percentage: 13 },
  ];

  const recentThreats = [
    {
      id: 1,
      url: 'https://paypal-secure-verify.tk',
      threat: 'Credential Phishing',
      risk: 94,
      time: '5 minutes ago',
      user: 'john.doe@company.com'
    },
    {
      id: 2,
      url: 'https://microsoft-account-security.com',
      threat: 'Brand Impersonation',
      risk: 89,
      time: '12 minutes ago',
      user: 'sarah.smith@company.com'
    },
    {
      id: 3,
      url: 'https://amazon-winner-prize.net',
      threat: 'Credential Phishing',
      risk: 92,
      time: '28 minutes ago',
      user: 'mike.johnson@company.com'
    },
    {
      id: 4,
      url: 'https://bank-urgent-update.info',
      threat: 'Domain Spoofing',
      risk: 87,
      time: '1 hour ago',
      user: 'lisa.wong@company.com'
    },
    {
      id: 5,
      url: 'https://apple-id-locked.com',
      threat: 'Credential Phishing',
      risk: 91,
      time: '2 hours ago',
      user: 'david.lee@company.com'
    },
  ];

  const handleQuickScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickScanURL.trim()) {
      onScanURL(quickScanURL.trim());
    }
  };

  const getColorClasses = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: 'bg-blue-100 text-blue-600',
      red: 'bg-red-100 text-red-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Security Dashboard</h1>
        <p className="text-gray-600">
          Real-time overview of your organization's phishing protection
        </p>
      </div>

      {/* Quick Scan */}
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="p-6">
          <h3 className="mb-4 text-white">Quick URL Scan</h3>
          <form onSubmit={handleQuickScan} className="flex gap-2">
            <Input
              type="text"
              placeholder="Enter URL to scan immediately..."
              value={quickScanURL}
              onChange={(e) => setQuickScanURL(e.target.value)}
              className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/60"
            />
            <Button type="submit" className="bg-white text-blue-600 hover:bg-gray-100">
              <Search className="w-4 h-4 mr-2" />
              Scan Now
            </Button>
          </form>
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <Card key={idx}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-2 rounded-lg ${getColorClasses(stat.color)}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`text-sm ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.change}
                  </span>
                </div>
                <div className="text-2xl mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Threat Types */}
        <Card className="lg:col-span-1">
          <div className="p-6">
            <h3 className="mb-4">Most Common Threats</h3>
            <div className="space-y-4">
              {threatTypes.map((threat, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">{threat.type}</span>
                    <span className="text-sm">{threat.count}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-red-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${threat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Recent Threats Feed */}
        <Card className="lg:col-span-2">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-red-600" />
                <h3>Recent Threats Detected</h3>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => onNavigate('history')}
              >
                View All
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
            <div className="space-y-3">
              {recentThreats.map((threat) => (
                <div 
                  key={threat.id}
                  className="flex items-start gap-3 p-3 rounded-lg bg-red-50 border border-red-100 hover:bg-red-100 transition-colors cursor-pointer"
                  onClick={() => onNavigate('history')}
                >
                  <div className="p-1.5 bg-red-100 rounded-full">
                    <XCircle className="w-4 h-4 text-red-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="text-sm truncate">{threat.url}</span>
                      <Badge className="bg-red-600 text-white text-xs shrink-0">
                        {threat.risk}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-600">
                      <span className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        {threat.threat}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {threat.time}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Detected for: {threat.user}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
