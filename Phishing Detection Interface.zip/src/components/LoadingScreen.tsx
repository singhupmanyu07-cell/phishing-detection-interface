import { Shield, Loader2 } from 'lucide-react';
import { Progress } from './ui/progress';
import { useState, useEffect } from 'react';

export function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(0);

  const steps = [
    'Analyzing URL structure...',
    'Checking domain reputation...',
    'Scanning for phishing patterns...',
    'Verifying SSL certificate...',
    'Generating risk assessment...'
  ];

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) return 100;
        return prev + 5;
      });
    }, 100);

    const stepInterval = setInterval(() => {
      setStep(prev => {
        if (prev >= steps.length - 1) return steps.length - 1;
        return prev + 1;
      });
    }, 400);

    return () => {
      clearInterval(progressInterval);
      clearInterval(stepInterval);
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4 relative">
              <Shield className="w-8 h-8 text-blue-600" />
              <Loader2 className="w-16 h-16 text-blue-600 animate-spin absolute" />
            </div>
            <h2 className="mb-2">Analyzing URL</h2>
            <p className="text-gray-600 text-sm">
              Our AI is scanning for threats...
            </p>
          </div>

          <div className="space-y-4">
            <Progress value={progress} className="h-2" />
            <div className="min-h-[24px] text-center">
              <p className="text-sm text-blue-600 animate-pulse">
                {steps[step]}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
