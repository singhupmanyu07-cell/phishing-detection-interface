interface RiskGaugeProps {
  score: number;
  status: 'safe' | 'warning' | 'danger';
}

export function RiskGauge({ score, status }: RiskGaugeProps) {
  const getColor = () => {
    if (status === 'safe') return '#10b981';
    if (status === 'warning') return '#f59e0b';
    return '#ef4444';
  };

  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="8"
          />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={getColor()}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center flex-col">
          <div className="text-3xl" style={{ color: getColor() }}>
            {score}
          </div>
          <div className="text-xs text-gray-500">Risk Score</div>
        </div>
      </div>
    </div>
  );
}
