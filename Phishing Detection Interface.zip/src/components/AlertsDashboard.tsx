import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { 
  Shield, 
  AlertTriangle, 
  TrendingUp, 
  Users,
  Download,
  Filter,
  Search
} from 'lucide-react';
import { Input } from './ui/input';

export function AlertsDashboard() {
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d'>('24h');

  const stats = [
    { label: 'Total Scans', value: '1,247', change: '+12%', icon: Shield, color: 'blue' },
    { label: 'Threats Blocked', value: '38', change: '+5%', icon: AlertTriangle, color: 'red' },
    { label: 'Protected Users', value: '156', change: '+8%', icon: Users, color: 'green' },
    { label: 'Detection Rate', value: '98.4%', change: '+2.1%', icon: TrendingUp, color: 'purple' },
  ];

  const alerts = [
    {
      id: 'ALT-2847',
      timestamp: '2025-10-10 14:32:15',
      url: 'https://paypal-secure-login.tk',
      user: 'john.doe@company.com',
      threat: 'Phishing',
      risk: 94,
      status: 'blocked',
      action: 'Auto-blocked'
    },
    {
      id: 'ALT-2846',
      timestamp: '2025-10-10 14:28:43',
      url: 'https://microsoft-verify-account.com',
      user: 'sarah.smith@company.com',
      threat: 'Domain Spoofing',
      risk: 87,
      status: 'blocked',
      action: 'Auto-blocked'
    },
    {
      id: 'ALT-2845',
      timestamp: '2025-10-10 14:15:22',
      url: 'https://amazon-prize-winner.net',
      user: 'mike.johnson@company.com',
      threat: 'Phishing',
      risk: 91,
      status: 'blocked',
      action: 'Auto-blocked'
    },
    {
      id: 'ALT-2844',
      timestamp: '2025-10-10 13:58:09',
      url: 'https://bank-security-update.com',
      user: 'lisa.wong@company.com',
      threat: 'Credential Harvesting',
      risk: 96,
      status: 'blocked',
      action: 'Auto-blocked'
    },
    {
      id: 'ALT-2843',
      timestamp: '2025-10-10 13:42:31',
      url: 'https://suspicious-site.info',
      user: 'david.lee@company.com',
      threat: 'Suspicious Activity',
      risk: 72,
      status: 'warned',
      action: 'User warned'
    },
  ];

  const getColorClasses = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: 'bg-blue-100 text-blue-600',
      red: 'bg-red-100 text-red-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="mb-2">Security Alerts Dashboard</h1>
            <p className="text-gray-600">
              Real-time monitoring of phishing threats across your organization
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Timeframe Selector */}
        <div className="flex gap-2">
          {(['24h', '7d', '30d'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                timeframe === tf
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Last {tf === '24h' ? '24 Hours' : tf === '7d' ? '7 Days' : '30 Days'}
            </button>
          ))}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <Card key={idx}>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-2 rounded-lg ${getColorClasses(stat.color)}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-sm text-green-600">{stat.change}</span>
                  </div>
                  <div className="text-2xl mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Alerts Table */}
        <Card>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3>Recent Threat Alerts</h3>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input 
                    placeholder="Search alerts..." 
                    className="pl-9 w-64"
                  />
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Alert ID</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Malicious URL</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Threat Type</TableHead>
                    <TableHead>Risk Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {alerts.map((alert) => (
                    <TableRow key={alert.id}>
                      <TableCell className="text-blue-600">
                        {alert.id}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {alert.timestamp}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-sm">
                        {alert.url}
                      </TableCell>
                      <TableCell className="text-sm">
                        {alert.user}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {alert.threat}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-1.5 max-w-[60px]">
                            <div 
                              className={`h-1.5 rounded-full ${
                                alert.risk >= 80 ? 'bg-red-500' : 
                                alert.risk >= 50 ? 'bg-amber-500' : 
                                'bg-green-500'
                              }`}
                              style={{ width: `${alert.risk}%` }}
                            />
                          </div>
                          <span className="text-sm">{alert.risk}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          alert.status === 'blocked' 
                            ? 'bg-red-100 text-red-800' 
                            : 'bg-amber-100 text-amber-800'
                        }>
                          {alert.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {alert.action}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
