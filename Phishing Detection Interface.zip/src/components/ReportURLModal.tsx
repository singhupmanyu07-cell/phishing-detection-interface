import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

interface ReportURLModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
  currentStatus: 'safe' | 'warning' | 'danger';
}

export function ReportURLModal({ isOpen, onClose, url, currentStatus }: ReportURLModalProps) {
  const [reportType, setReportType] = useState('false-positive');
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    // Mock submission
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFeedback('');
      onClose();
    }, 2000);
  };

  if (submitted) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <div className="text-center py-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="mb-2">Thank You!</h3>
            <p className="text-gray-600">
              Your feedback has been submitted and will help improve our detection model.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Report URL Classification</DialogTitle>
          <DialogDescription>
            Help us improve our AI model by reporting misclassified URLs
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* URL Display */}
          <div>
            <Label>URL Being Reported</Label>
            <div className="mt-2 p-3 bg-gray-50 rounded-lg break-all text-sm">
              {url}
            </div>
            <div className="mt-2 text-sm text-gray-600">
              Current classification: <span className="font-medium">{currentStatus.toUpperCase()}</span>
            </div>
          </div>

          {/* Report Type */}
          <div className="space-y-3">
            <Label>What would you like to report?</Label>
            <RadioGroup value={reportType} onValueChange={setReportType}>
              <div className="flex items-start space-x-2 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="false-positive" id="false-positive" className="mt-0.5" />
                <div className="flex-1">
                  <Label htmlFor="false-positive" className="cursor-pointer">
                    False Positive
                  </Label>
                  <p className="text-sm text-gray-600 mt-1">
                    This URL is safe but was flagged as suspicious/malicious
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-2 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="false-negative" id="false-negative" className="mt-0.5" />
                <div className="flex-1">
                  <Label htmlFor="false-negative" className="cursor-pointer">
                    False Negative
                  </Label>
                  <p className="text-sm text-gray-600 mt-1">
                    This URL is malicious but was marked as safe
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-2 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="other" id="other" className="mt-0.5" />
                <div className="flex-1">
                  <Label htmlFor="other" className="cursor-pointer">
                    Other Issue
                  </Label>
                  <p className="text-sm text-gray-600 mt-1">
                    Different concern or feedback about this classification
                  </p>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Additional Feedback */}
          <div className="space-y-2">
            <Label htmlFor="feedback">Additional Details (Optional)</Label>
            <Textarea
              id="feedback"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Provide any additional context that might help us improve..."
              className="min-h-[100px]"
            />
          </div>

          {/* Info Alert */}
          <div className="flex gap-3 p-3 bg-blue-50 rounded-lg">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              Your feedback helps train our AI model. Reports are reviewed by our security team and contribute to continuous improvement.
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleSubmit} className="flex-1 bg-blue-600 hover:bg-blue-700">
              Submit Report
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
