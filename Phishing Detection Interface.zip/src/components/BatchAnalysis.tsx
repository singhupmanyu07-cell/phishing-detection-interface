import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  Download,
  Trash2
} from 'lucide-react';

interface BatchResult {
  url: string;
  status: 'safe' | 'warning' | 'danger';
  riskScore: number;
}

export function BatchAnalysis() {
  const [urls, setUrls] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<BatchResult[]>([]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setUrls(content);
      };
      reader.readAsText(file);
    }
  };

  const analyzeBatch = () => {
    const urlList = urls.split('\n').filter(url => url.trim());
    if (urlList.length === 0) return;

    setIsAnalyzing(true);
    setProgress(0);
    setResults([]);

    // Simulate batch analysis
    const totalUrls = urlList.length;
    let processed = 0;

    const interval = setInterval(() => {
      if (processed >= totalUrls) {
        clearInterval(interval);
        setIsAnalyzing(false);
        return;
      }

      const url = urlList[processed];
      const urlLower = url.toLowerCase();
      
      // Mock analysis logic
      let status: 'safe' | 'warning' | 'danger' = 'safe';
      let riskScore = 5;

      const dangerPatterns = ['login', 'verify', 'secure-', 'account-', '.tk', '.ga', 'prize', 'winner'];
      const warningPatterns = ['free', 'click', 'limited', 'urgent'];

      if (dangerPatterns.some(pattern => urlLower.includes(pattern))) {
        status = 'danger';
        riskScore = 85 + Math.floor(Math.random() * 15);
      } else if (warningPatterns.some(pattern => urlLower.includes(pattern))) {
        status = 'warning';
        riskScore = 45 + Math.floor(Math.random() * 25);
      } else {
        riskScore = 3 + Math.floor(Math.random() * 7);
      }

      setResults(prev => [...prev, { url, status, riskScore }]);
      processed++;
      setProgress(Math.round((processed / totalUrls) * 100));
    }, 300);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe': return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      case 'danger': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: string } = {
      safe: 'bg-green-100 text-green-800',
      warning: 'bg-amber-100 text-amber-800',
      danger: 'bg-red-100 text-red-800'
    };
    
    return (
      <Badge className={variants[status]}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const summary = {
    total: results.length,
    safe: results.filter(r => r.status === 'safe').length,
    warning: results.filter(r => r.status === 'warning').length,
    danger: results.filter(r => r.status === 'danger').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Batch URL Analysis</h1>
        <p className="text-gray-600">
          Scan multiple URLs simultaneously for efficient threat detection
        </p>
      </div>

      {/* Input Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <div className="p-6">
            <h3 className="mb-4">Enter URLs</h3>
            <p className="text-sm text-gray-600 mb-4">
              Paste URLs (one per line) or upload a text/CSV file
            </p>
            <Textarea
              placeholder="https://example1.com&#10;https://example2.com&#10;https://example3.com"
              value={urls}
              onChange={(e) => setUrls(e.target.value)}
              className="min-h-[200px] mb-4"
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload File
              </Button>
              <input
                id="file-upload"
                type="file"
                accept=".txt,.csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button
                variant="outline"
                onClick={() => setUrls('')}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <h3 className="mb-4">Instructions</h3>
            <div className="space-y-4 text-sm">
              <div className="flex gap-3">
                <FileText className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <div>
                  <div className="mb-1">Supported Formats</div>
                  <div className="text-gray-600">
                    Plain text (.txt) or CSV files with one URL per line
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                <div>
                  <div className="mb-1">Fast Processing</div>
                  <div className="text-gray-600">
                    Analyze up to 1,000 URLs in a single batch
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <Download className="w-5 h-5 text-purple-600 flex-shrink-0" />
                <div>
                  <div className="mb-1">Export Results</div>
                  <div className="text-gray-600">
                    Download results as CSV for further analysis
                  </div>
                </div>
              </div>
            </div>

            <Button
              onClick={analyzeBatch}
              disabled={!urls.trim() || isAnalyzing}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze All URLs'}
            </Button>
          </div>
        </Card>
      </div>

      {/* Progress */}
      {isAnalyzing && (
        <Card>
          <div className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm">Analyzing URLs...</span>
              <span className="text-sm">{progress}%</span>
            </div>
            <Progress value={progress} />
          </div>
        </Card>
      )}

      {/* Results */}
      {results.length > 0 && (
        <>
          <Card>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3>Analysis Summary</h3>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Download className="w-4 h-4 mr-2" />
                  Export Results
                </Button>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl mb-1">{summary.total}</div>
                  <div className="text-sm text-gray-600">Total Scanned</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl text-green-600 mb-1">{summary.safe}</div>
                  <div className="text-sm text-gray-600">Safe</div>
                </div>
                <div className="text-center p-4 bg-amber-50 rounded-lg">
                  <div className="text-2xl text-amber-600 mb-1">{summary.warning}</div>
                  <div className="text-sm text-gray-600">Warning</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl text-red-600 mb-1">{summary.danger}</div>
                  <div className="text-sm text-gray-600">Danger</div>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <div className="p-6">
              <h3 className="mb-4">Detailed Results</h3>
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {results.map((result, idx) => (
                  <div 
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {getStatusIcon(result.status)}
                      <span className="text-sm truncate">{result.url}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-1.5">
                          <div 
                            className={`h-1.5 rounded-full ${
                              result.riskScore >= 80 ? 'bg-red-500' : 
                              result.riskScore >= 50 ? 'bg-amber-500' : 
                              'bg-green-500'
                            }`}
                            style={{ width: `${result.riskScore}%` }}
                          />
                        </div>
                        <span className="text-sm w-8">{result.riskScore}</span>
                      </div>
                      {getStatusBadge(result.status)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
