import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Button } from './components/ui/button';
import { 
  Home, 
  LayoutDashboard, 
  History, 
  Layers, 
  Bell, 
  BookOpen, 
  Chrome,
  Menu,
  X,
  Brain
} from 'lucide-react';

// Main App Components
import { URLInputScreen } from './components/URLInputScreen';
import { LoadingScreen } from './components/LoadingScreen';
import { ResultsScreen, type AnalysisResult } from './components/ResultsScreen';

// Organizational Portal Components
import { OrganizationalDashboard } from './components/OrganizationalDashboard';
import { ScanHistory } from './components/ScanHistory';
import { BatchAnalysis } from './components/BatchAnalysis';
import { AlertsReporting } from './components/AlertsReporting';

// User Engagement Components
import { EducationalResources } from './components/EducationalResources';
import { ModelInformation } from './components/ModelInformation';

// Browser Extension Components
import { BrowserExtensionEnhanced } from './components/BrowserExtensionEnhanced';

type AppScreen = 'input' | 'loading' | 'results';
type PortalPage = 'dashboard' | 'history' | 'batch' | 'alerts';

function App() {
  const [currentView, setCurrentView] = useState<'public' | 'portal' | 'extension' | 'education' | 'model'>('public');
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('input');
  const [portalPage, setPortalPage] = useState<PortalPage>('dashboard');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Mock analysis function
  const analyzeURL = (url: string): AnalysisResult => {
    const dangerousPatterns = ['login', 'verify', 'secure-', 'account-', '.tk', '.ga', 'prize', 'winner'];
    const warningPatterns = ['free', 'click', 'limited', 'urgent'];
    
    const urlLower = url.toLowerCase();
    const isDangerous = dangerousPatterns.some(pattern => urlLower.includes(pattern));
    const isWarning = warningPatterns.some(pattern => urlLower.includes(pattern));
    
    let status: 'safe' | 'warning' | 'danger' = 'safe';
    let riskScore = 5;
    let factors: AnalysisResult['factors'] = [];

    if (isDangerous) {
      status = 'danger';
      riskScore = 85 + Math.floor(Math.random() * 15);
      factors = [
        { type: 'negative', icon: 'link', text: 'URL contains suspicious keywords' },
        { type: 'negative', icon: 'clock', text: 'Domain was registered recently (NRD)' },
        { type: 'negative', icon: 'alert', text: 'Domain mimics a legitimate brand' },
        { type: 'negative', icon: 'file', text: 'Suspicious page structure detected' },
        { type: 'positive', icon: 'lock', text: 'SSL certificate is present (but unverified)' },
      ];
    } else if (isWarning) {
      status = 'warning';
      riskScore = 45 + Math.floor(Math.random() * 25);
      factors = [
        { type: 'negative', icon: 'alert', text: 'URL uses attention-grabbing language' },
        { type: 'negative', icon: 'file', text: 'Minimal webpage content detected' },
        { type: 'positive', icon: 'lock', text: 'Valid SSL certificate' },
        { type: 'positive', icon: 'shield', text: 'Domain age is acceptable' },
        { type: 'positive', icon: 'link', text: 'No known malicious redirects' },
      ];
    } else {
      riskScore = 3 + Math.floor(Math.random() * 7);
      factors = [
        { type: 'positive', icon: 'shield', text: 'Domain has good reputation' },
        { type: 'positive', icon: 'clock', text: 'Domain age is well-established' },
        { type: 'positive', icon: 'lock', text: 'Valid SSL certificate from trusted CA' },
        { type: 'positive', icon: 'file', text: 'Webpage content appears legitimate' },
        { type: 'positive', icon: 'link', text: 'No suspicious URL patterns detected' },
      ];
    }

    return { url, status, riskScore, factors };
  };

  const handleURLSubmit = (url: string) => {
    setCurrentScreen('loading');
    
    setTimeout(() => {
      const result = analyzeURL(url);
      setAnalysisResult(result);
      setCurrentScreen('results');
    }, 2000);
  };

  const handleBack = () => {
    setCurrentScreen('input');
    setAnalysisResult(null);
  };

  const handlePortalNavigation = (page: PortalPage) => {
    setPortalPage(page);
    setMobileMenuOpen(false);
  };

  const handleQuickScan = (url: string) => {
    setCurrentView('public');
    handleURLSubmit(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Navigation */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <div>
                <div className="font-semibold">Phishing Detector</div>
                <div className="text-xs text-gray-600 hidden sm:block">AI-Powered Security Platform</div>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center gap-2">
              <Button
                variant={currentView === 'public' ? 'default' : 'ghost'}
                onClick={() => setCurrentView('public')}
                className={currentView === 'public' ? 'bg-blue-600' : ''}
              >
                <Home className="w-4 h-4 mr-2" />
                Scanner
              </Button>
              <Button
                variant={currentView === 'portal' ? 'default' : 'ghost'}
                onClick={() => setCurrentView('portal')}
                className={currentView === 'portal' ? 'bg-blue-600' : ''}
              >
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Organization
              </Button>
              <Button
                variant={currentView === 'model' ? 'default' : 'ghost'}
                onClick={() => setCurrentView('model')}
                className={currentView === 'model' ? 'bg-blue-600' : ''}
              >
                <Brain className="w-4 h-4 mr-2" />
                Model Info
              </Button>
              <Button
                variant={currentView === 'education' ? 'default' : 'ghost'}
                onClick={() => setCurrentView('education')}
                className={currentView === 'education' ? 'bg-blue-600' : ''}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Learn
              </Button>
              <Button
                variant={currentView === 'extension' ? 'default' : 'ghost'}
                onClick={() => setCurrentView('extension')}
                className={currentView === 'extension' ? 'bg-blue-600' : ''}
              >
                <Chrome className="w-4 h-4 mr-2" />
                Extension
              </Button>
            </nav>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t space-y-2">
              <Button
                variant={currentView === 'public' ? 'default' : 'ghost'}
                onClick={() => { setCurrentView('public'); setMobileMenuOpen(false); }}
                className={`w-full justify-start ${currentView === 'public' ? 'bg-blue-600' : ''}`}
              >
                <Home className="w-4 h-4 mr-2" />
                Scanner
              </Button>
              <Button
                variant={currentView === 'portal' ? 'default' : 'ghost'}
                onClick={() => { setCurrentView('portal'); setMobileMenuOpen(false); }}
                className={`w-full justify-start ${currentView === 'portal' ? 'bg-blue-600' : ''}`}
              >
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Organization
              </Button>
              <Button
                variant={currentView === 'model' ? 'default' : 'ghost'}
                onClick={() => { setCurrentView('model'); setMobileMenuOpen(false); }}
                className={`w-full justify-start ${currentView === 'model' ? 'bg-blue-600' : ''}`}
              >
                <Brain className="w-4 h-4 mr-2" />
                Model Info
              </Button>
              <Button
                variant={currentView === 'education' ? 'default' : 'ghost'}
                onClick={() => { setCurrentView('education'); setMobileMenuOpen(false); }}
                className={`w-full justify-start ${currentView === 'education' ? 'bg-blue-600' : ''}`}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Learn
              </Button>
              <Button
                variant={currentView === 'extension' ? 'default' : 'ghost'}
                onClick={() => { setCurrentView('extension'); setMobileMenuOpen(false); }}
                className={`w-full justify-start ${currentView === 'extension' ? 'bg-blue-600' : ''}`}
              >
                <Chrome className="w-4 h-4 mr-2" />
                Extension
              </Button>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>
        {/* Public Scanner View */}
        {currentView === 'public' && (
          <>
            {currentScreen === 'input' && <URLInputScreen onSubmit={handleURLSubmit} />}
            {currentScreen === 'loading' && <LoadingScreen />}
            {currentScreen === 'results' && analysisResult && (
              <ResultsScreen result={analysisResult} onBack={handleBack} />
            )}
          </>
        )}

        {/* Organizational Portal View */}
        {currentView === 'portal' && (
          <div className="flex min-h-[calc(100vh-4rem)]">
            {/* Sidebar */}
            <aside className="hidden lg:block w-64 bg-white border-r">
              <nav className="p-4 space-y-2">
                <Button
                  variant={portalPage === 'dashboard' ? 'default' : 'ghost'}
                  onClick={() => handlePortalNavigation('dashboard')}
                  className={`w-full justify-start ${portalPage === 'dashboard' ? 'bg-blue-600' : ''}`}
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
                <Button
                  variant={portalPage === 'history' ? 'default' : 'ghost'}
                  onClick={() => handlePortalNavigation('history')}
                  className={`w-full justify-start ${portalPage === 'history' ? 'bg-blue-600' : ''}`}
                >
                  <History className="w-4 h-4 mr-2" />
                  Scan History
                </Button>
                <Button
                  variant={portalPage === 'batch' ? 'default' : 'ghost'}
                  onClick={() => handlePortalNavigation('batch')}
                  className={`w-full justify-start ${portalPage === 'batch' ? 'bg-blue-600' : ''}`}
                >
                  <Layers className="w-4 h-4 mr-2" />
                  Batch Analysis
                </Button>
                <Button
                  variant={portalPage === 'alerts' ? 'default' : 'ghost'}
                  onClick={() => handlePortalNavigation('alerts')}
                  className={`w-full justify-start ${portalPage === 'alerts' ? 'bg-blue-600' : ''}`}
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Alerts & Reports
                </Button>
              </nav>
            </aside>

            {/* Mobile Portal Navigation */}
            <div className="lg:hidden w-full bg-white border-b p-4">
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={portalPage === 'dashboard' ? 'default' : 'outline'}
                  onClick={() => handlePortalNavigation('dashboard')}
                  size="sm"
                  className={portalPage === 'dashboard' ? 'bg-blue-600' : ''}
                >
                  <LayoutDashboard className="w-4 h-4 mr-1" />
                  Dashboard
                </Button>
                <Button
                  variant={portalPage === 'history' ? 'default' : 'outline'}
                  onClick={() => handlePortalNavigation('history')}
                  size="sm"
                  className={portalPage === 'history' ? 'bg-blue-600' : ''}
                >
                  <History className="w-4 h-4 mr-1" />
                  History
                </Button>
                <Button
                  variant={portalPage === 'batch' ? 'default' : 'outline'}
                  onClick={() => handlePortalNavigation('batch')}
                  size="sm"
                  className={portalPage === 'batch' ? 'bg-blue-600' : ''}
                >
                  <Layers className="w-4 h-4 mr-1" />
                  Batch
                </Button>
                <Button
                  variant={portalPage === 'alerts' ? 'default' : 'outline'}
                  onClick={() => handlePortalNavigation('alerts')}
                  size="sm"
                  className={portalPage === 'alerts' ? 'bg-blue-600' : ''}
                >
                  <Bell className="w-4 h-4 mr-1" />
                  Alerts
                </Button>
              </div>
            </div>

            {/* Portal Content */}
            <div className="flex-1 p-6 lg:p-8 overflow-auto">
              {portalPage === 'dashboard' && (
                <OrganizationalDashboard 
                  onNavigate={handlePortalNavigation}
                  onScanURL={handleQuickScan}
                />
              )}
              {portalPage === 'history' && <ScanHistory />}
              {portalPage === 'batch' && <BatchAnalysis />}
              {portalPage === 'alerts' && <AlertsReporting />}
            </div>
          </div>
        )}

        {/* Model Information View */}
        {currentView === 'model' && (
          <div className="p-6 lg:p-8 max-w-7xl mx-auto">
            <ModelInformation />
          </div>
        )}

        {/* Educational Resources View */}
        {currentView === 'education' && (
          <div className="p-6 lg:p-8 max-w-7xl mx-auto">
            <EducationalResources />
          </div>
        )}

        {/* Browser Extension View */}
        {currentView === 'extension' && (
          <div className="p-6 lg:p-8 max-w-7xl mx-auto">
            <BrowserExtensionEnhanced />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
